//
//  Person+CoreDataClass.swift
//  TTT
//
//  Created by Feliciano Medina on 2/28/25.
//
//

import Foundation
import CoreData

@objc(Person)
public class Person: NSManagedObject {

}
